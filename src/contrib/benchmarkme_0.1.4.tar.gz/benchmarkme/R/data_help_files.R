#' @rdname data_results
#' @name results
#' @title Benchmarking results
#' @description A summary of past benchmarks. The full data set will be 
#' made available in a companion package
#' @docType data
#' @format A data frame
NULL