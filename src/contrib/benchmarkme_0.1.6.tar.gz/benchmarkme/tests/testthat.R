library(testthat)
test_check("benchmarkme")
