## Not used
get_arithmetic_info = function() {
  .Machine
}
