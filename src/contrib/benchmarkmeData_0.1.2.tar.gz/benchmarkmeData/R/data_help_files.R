#' @rdname past_results
#' @name past_results
#' @title Benchmarking results
#' @description A summary of past benchmarks. 
#' @docType data
#' @format A data frame
NULL
