.bme_env = new.env(parent=emptyenv()) 
.bme_env$results = NULL