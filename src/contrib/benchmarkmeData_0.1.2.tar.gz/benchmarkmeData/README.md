# Benchmarkme data
[![Build Status](https://travis-ci.org/csgillespie/benchmarkme-data.svg?branch=master)](https://travis-ci.org/csgillespie/benchmarkme-data)
[![codecov.io](https://codecov.io/github/csgillespie/benchmarkme-data/coverage.svg?branch=master)](https://codecov.io/github/csgillespie/benchmarkme-data?branch=master)
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/benchmarkmeData)](http://cran.r-project.org/package=benchmarkmeData)


An R package containing the uploaded results from the [benchmarkme](https://github.com/csgillespie/benchmarkme) benchmarking package.