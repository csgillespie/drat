# Benchmarkme data
[![Build Status](https://travis-ci.org/csgillespie/benchmarkme-data.svg?branch=master)](https://travis-ci.org/csgillespie/benchmarkme-data)
[![CRAN_Status_Badge](http://www.r-pkg.org/badges/version/benchmarkmeData)](http://cran.r-project.org/package=benchmarkmeData)


An R package containing the uploaded results from the [benchmarkme](https://github.com/csgillespie/benchmarkme) benchmarking package.