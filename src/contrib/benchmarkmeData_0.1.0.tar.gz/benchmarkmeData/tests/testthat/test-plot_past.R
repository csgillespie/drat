test_that("Test plot_past", {
  skip_on_cran()
  expect_null(plot_past())
}
)
