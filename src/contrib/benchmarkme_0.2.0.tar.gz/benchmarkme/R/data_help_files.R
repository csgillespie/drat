#' @rdname sample_results
#' @name sample_results
#' @title Sample benchmarking results
#' @description Sample benchmark results. Used in the vignette.
#' @docType data
#' @format A data frame
NULL
