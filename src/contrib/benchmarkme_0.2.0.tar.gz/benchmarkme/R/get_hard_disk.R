## A work in progress
# get_hard_drive = function() {
#   if(Sys.info()["sysname"]=="Windows") {
#     cmd = "C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe get-wmiobject win32_diskdrive"
#     hard_disk = system(cmd, intern=TRUE)
#   }
# }


# cmd = "C:\\WINDOWS\\system32\\WindowsPowerShell\\v1.0\\powershell.exe get-wmiobject win32_diskdrive"
# system(cmd)
# 
# 
# Partitions : 2
# DeviceID   : \\.\PHYSICALDRIVE0
# Model      : SAMSUNG MZ7PD128HCFV-000 SCSI Disk Device
# Size       : 128034708480
# Caption    : SAMSUNG MZ7PD128HCFV-000 SCSI Disk Device
