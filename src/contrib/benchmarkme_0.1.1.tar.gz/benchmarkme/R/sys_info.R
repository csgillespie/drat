#' System info
#' 
#' Returns \code{Sys.info()}
#' @export
get_sys_info = function() Sys.info()