## Version 0.2.2
  * Add quotes to `benchmarkme` in DESCRIPTION file.
  
## Version 0.2.1
  * Match benchmarkme version.
  * First version on CRAN

## Version 0.1.3
  * Updated data set
  * Include byte-compile flag
  * Added shiny interface (`shine`)

## Version 0.1.2
  * Update data set

## Version 0.1.1
  * Include OS and RAM in data set.
  * Include read/write benchmarks.

## Version 0.1.0
  * First public release.