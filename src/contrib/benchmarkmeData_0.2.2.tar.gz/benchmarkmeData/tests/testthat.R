library("testthat")
test_check("benchmarkmeData")
