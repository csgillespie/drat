#' A simple adding functions
#'
#' An example adding function
#' @param x a number
#' @param y another number
#' @examples
#' add(1, 2)
#' @export
add = function(x, y){
  x + y
}
