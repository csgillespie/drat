#' @import coin
NULL
