#' R courses at Newcastle University
#' 
#' Functions and datasets used in for external R courses at Newcastle University
#' @name nclRmodelling-package
#' @aliases nclRmodelling
#' @docType package
#' @keywords package
NULL