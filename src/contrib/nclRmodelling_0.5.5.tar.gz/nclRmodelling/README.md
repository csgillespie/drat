# Statistical modelling [![Build Status](https://api.travis-ci.org/rcourses/nclRmodelling.png?branch=master)](https://travis-ci.org/rcourses/nclRmodeling)

Course material for the [Statistical modelling](http://www.ncl.ac.uk/maths/rcourse/) course. 
