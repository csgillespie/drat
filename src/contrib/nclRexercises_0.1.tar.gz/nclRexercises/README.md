# R teaching exercies

The initial idea for this package was from the [rstudio/reportWS](https://github.com/rstudio/reportsWS/)
package.
