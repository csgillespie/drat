#' Open an exercise
#'
#' \code{exercise} opens an exercise file in your RStudio scripts pane and 
#' saves a copy of the file in your working directory.
#' 
#' @details Heavily based on the code in the reportsWS package.
#'
#' @param number The number of exercise to open.
#' @return NULL 
#'
#' @export
exercise = function(number=1) {
  if (!(number %in% 1:2)) stop("Unrecognized exercise number")
  
  filename = switch(number,
                     "1" = "exercise1.Rmd",
                     "2" = "exercise2.Rmd"
  )
  
  path = system.file("exercises", filename, package = "nclRexercises")
  newpath = file.path(getwd(), filename)
  file.copy(path, newpath, copy.mode = FALSE)
  file.edit(newpath)
  
  if (number == 1) {
    img = system.file("exercises", "headerlog.png", package = "nclRexercises")
    file.copy(img, newpath, copy.mode = FALSE)
  }
}