## Version 0.1.1
  * Include OS and RAM in data set.
  * Include read/write benchmarks.

## Version 0.1.0
  * First public release.