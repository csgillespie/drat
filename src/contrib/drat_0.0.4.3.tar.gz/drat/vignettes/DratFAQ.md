---
title: "Drat Frequently Asked Questions"
author: "Dirk Eddelbuettel"
date: "2015-05-24"
output: rmarkdown::html_vignette
vignette: >
  %\VignetteIndexEntry{Drat Frequently Asked Questions}
  %\VignetteEngine{knitr::rmarkdown}
  \usepackage[utf8]{inputenc}
---

## What is drat?

Good question.  Drat is an R package which makes it really easy to provide R
packages via a _repository_, and also makes it easy to use such repositories
for package installation and upgrades.

## Where is drat?

drat itself is a package, so it has source code (on GitHub) and a package (on
the main R repository network).

But wait: we also call the repositories created or used via drat "drat"
repositories.  So we have to distinguish between "drat the package" and "a
drat repository" created or used by it.

Hope this clarified things a little. Drat really can be different things
which reside in different places but it aims to be _a helper package which
helps creating and using R package repositories easier_.

## What other documentation is there?

Glad you asked.  We have written

+ a [package webpage](http://dirk.eddelbuettel.com/code/drat.html) giving a
first instroduction
+ several [blog posts](http://dirk.eddelbuettel.com/blog/code/drat/) on the package
and its releases
+ the [GitHub page README](http://github.com/eddelbuettel/drat)
+ several [vignettes accessible from the package page](http://cran.rstudio.com/package=drat)
and other places.
+ the [drat repo page](http://eddelbuettel.github.io/drat)


## Why the focus on GitHub?

Several answers:

+ Because it is there and used by ever increasing numbers of package authors.
+ Because it is pretty fast and reliable, no matter where in the world you are.
+ Because it _already gives every repository owner a web-server_ via the
gh-pages branch.
+ Because all we need is a web-server and some file system space
+ Because the single variable `user` uniquely identifies a URL
`user.github.io/drat/`, and communicating a single variable is easier than
communicating a full URL

Taken together, we have this a pretty good to _default on GitHub_ for
repositories.  But read on ...

## What if not GitHub?

Fear not, as drat also supports repositories on a local drive, or shared
network drive, or actually just about anything where you can write to or read
from.

We detail that in the corresponding vignettes.

## Why could install_github be wrong?

`install_github()` is a fine tool and does want it sets out to do: grab a
snapshot from GitHub and install it.  This can be he HEAD (by default), or a
tag, or a commit, or from a branch.

But we think that is not what R needs. R has become so very successful for
many reasons, but (in the eyes of many) one key part of the success was
_repositories_ ensuring both _easy installation_ and _easy upgrades_.

That second point is lost on `install_github()`: it installs what we may call
"orphans".  Packages that are disconnected from an upgrade path.  (With the
exception, of course, of a newer version of what you install appearing in a
known repository so that `update.packages` will see it.)  We think that is a
disservice to the users, and a repository can do better in a fundamental way
than provide access to (somewhat random) commits.  Of course, one _could_ write
new code building on top of `install_github()` and adding the functionality.
But then, why? R already has this functionality, and had it for decades:
using repositories.  So drat does not aim to replace `install_github()`; it
simply aims at something both different and possibly much simpler.

Moreover, drat puts the "release" option back into the hand of the _package
authors_. By cutting a release tarball and placing it into a repository, we
think a possibly more informed release snapshot is distributed than by
pointing at any branch of repository.

And last but not least, drat (>= 0.0.4) and its repositories also support binary
installations.

## Can drat work with binaries?

You bet.  Jan Schulz provided a [careful pull request](https://github.com/eddelbuettel/drat/pull/16).
He now uses drat with Windows binaries in a repo for the
[IRkernel](https://github.com/IRkernel/IRkernel) project.

However, not all functions have been extended, and support for OS X has not
been added either.  Contributions would be more than welcome.

## Can drat act as an `Additional_repositories` ?

Glad you asked!  See the last line of the `DESCRIPTION` file of the
[wikipediatrend package](https://github.com/petermeissner/wikipediatrend/blob/master/DESCRIPTION)
and its [official repository page](http://cran.rstudio.com/web/packages/wikipediatrend/index.html).
It very happily uses the [ghrr](http://ghrr.github.io/drat) drat repo to
provide the two suggested packages [AnomalyDetection](https://github.com/twitter/AnomalyDetection) and
[BreakoutDetection](https://github.com/twitter/BreakoutDetection).

## What about the miniCRAN package?

The [miniCRAN](http://cran.rstudio.com/package=miniCRAN) package creates
self-sufficient repositories by examining the dependency graph and
downloading all dependent packages.  As such, it is more of complement to
drat than an alternative --- and Word is that several people have in fact
combined both.

