
#' @export
get_arithmetic_info = function() {
  .Machine
}
