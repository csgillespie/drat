
#' @export
get_r_version = function() unclass(R.version)

