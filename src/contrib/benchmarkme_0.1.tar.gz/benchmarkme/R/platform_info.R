#' Platform Info
#' @return Returns \code{.Platform}
#' @export
get_platform_info = function() {
  .Platform
}
